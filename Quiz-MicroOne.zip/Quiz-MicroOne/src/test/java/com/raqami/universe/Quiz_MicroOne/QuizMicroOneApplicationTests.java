package com.raqami.universe.Quiz_MicroOne;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuizMicroOneApplicationTests {

	@Test
	void contextLoads() {
	}

}
