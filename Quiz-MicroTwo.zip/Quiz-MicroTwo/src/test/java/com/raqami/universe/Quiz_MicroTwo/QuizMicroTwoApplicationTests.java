package com.raqami.universe.Quiz_MicroTwo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuizMicroTwoApplicationTests {

	@Test
	void contextLoads() {
	}

}
